package com.varsitycollege.st10087432

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val numberEditText1: EditText = findViewById(R.id.editTextNumber)
        val numberEditText2: EditText = findViewById(R.id.editTextNumber2)
        val resultEditText: EditText = findViewById(R.id.editTextNumber3)

        val addButton: Button = findViewById(R.id.button5)
        val subtractButton: Button = findViewById(R.id.button6)
        val multiplyButton: Button = findViewById(R.id.button7)
        val divideButton: Button = findViewById(R.id.button8)

        addButton.setOnClickListener {
            val num1 = numberEditText1.text.toString().toDoubleOrNull() ?: 0.0
            val num2 = numberEditText2.text.toString().toDoubleOrNull() ?: 0.0
            val result = num1 + num2
            resultEditText.setText("Sum: $num1 + $num2 = $result")
        }

        subtractButton.setOnClickListener {
            val num1 = numberEditText1.text.toString().toDoubleOrNull() ?: 0.0
            val num2 = numberEditText2.text.toString().toDoubleOrNull() ?: 0.0
            val result = num1 - num2
            resultEditText.setText("Difference: $num1 - $num2 = $result")
        }

        multiplyButton.setOnClickListener {
            val num1 = numberEditText1.text.toString().toDoubleOrNull() ?: 0.0
            val num2 = numberEditText2.text.toString().toDoubleOrNull() ?: 0.0
            val result = num1 * num2
            resultEditText.setText("Product: $num1 * $num2 = $result")
        }

        divideButton.setOnClickListener {
            val num1 = numberEditText1.text.toString().toDoubleOrNull() ?: 0.0
            val num2 = numberEditText2.text.toString().toDoubleOrNull() ?: 1.0 // Avoid division by zero
            val result = num1 / num2
            resultEditText.setText("Quotient: $num1 / $num2 = $result")
        }
    }
}

